#!/bin/bash

echo "fake-python-1 called" >&2
exit 1
