#!/bin/bash

echo "fake-python-2 called" >&2
exit 1
